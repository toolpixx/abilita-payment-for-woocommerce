=== abilita PAY ===
Contributors: abilita
Tags: payment, woocommerce, invoice, sepa, directpayment
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 1.0.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Eine Kurze Beschreibung des Plugins

== Beschreibung ==

Beschreibung des Plugins

= Features =

Funktionen des Plugins

== Frequently Asked Questions ==

Fragen und Antworten

= Gibt es ein Inkasso? =

Ja über abilita kannst Du auch direkt das Inkasso durchführen

== Changelog ==

= 1.0.0 = *(10.02.2025)*

* Initial version

= 1.0.1 = *(24.02.2025)*

* Fix preferences-link in plugin overview. If user click the link, an alert show, that the user has no permission to do that

= 1.0.2 = *(27.02.2025)*

* If customer set no vat-id in the plugin-preferences and the customer is no b2b-customer the birthday-fields will not show.
* Abilita-Metabox in the order-detail-view will occured an error (With WooCommerce: Version 8.1.1|9.3.3)

= 1.0.3 = *(27.02.2025)*

* validate_Title must validate_title

= 1.0.4 = *(11.03.2025)*

* Remove ABILITA_BANK_ACCOUNT_HOLDER from source an use $this->bankAccountHolder

== Screenshots ==

1. Frontend Screenshot
2. Backend Screenshot